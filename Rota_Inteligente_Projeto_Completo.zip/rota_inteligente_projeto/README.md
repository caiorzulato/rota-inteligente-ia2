# Rota Inteligente: Otimização de Entregas com Algoritmos de IA

**Projeto acadêmico | Artificial Intelligence Fundamentals**

## 1. Descrição do problema

A empresa fictícia **Sabor Express**, que realiza entregas de alimentos na região central de uma cidade, enfrenta atrasos e custos elevados porque os trajetos são definidos manualmente. O projeto propõe um protótipo que representa a região como um grafo e utiliza algoritmos clássicos para apoiar o planejamento das entregas.

O objetivo é:
- encontrar caminhos de menor distância entre pontos conectados;
- organizar várias entregas em uma sequência prática;
- agrupar entregas geograficamente próximas;
- comparar uma rota de referência com a rota sugerida pelo protótipo.

> **Escopo e limitação:** os bairros, coordenadas, ruas e distâncias deste projeto são dados fictícios criados para fins didáticos. O programa não consulta mapas, trânsito ou endereços reais e, portanto, não deve ser usado como sistema de navegação operacional.

## 2. Abordagem adotada

A cidade é representada por um **grafo não direcionado**:
- **vértices (nós):** restaurante e pontos de entrega;
- **arestas:** ligações entre locais;
- **peso:** distância estimada em quilômetros.

O programa utiliza três etapas:

1. **Busca A\* (A-star):** calcula um caminho de menor custo entre dois nós do grafo. A função heurística é a distância em linha reta entre as coordenadas fictícias dos nós.
2. **Planejamento de múltiplas paradas:** aplica uma estratégia gulosa de vizinho mais próximo. A partir do restaurante, escolhe a próxima entrega ainda não visitada que esteja mais perto pelo caminho calculado com A\*. Repete até visitar todos os pontos e retorna à base.
3. **K-Means:** agrupa as entregas em duas zonas, usando as coordenadas fictícias (x, y). O número de grupos pode ser alterado no código.

A estratégia gulosa é uma aproximação: ela é simples e rápida, mas não garante a melhor sequência global possível para todas as paradas.

## 3. Algoritmos e conceitos

### A\*
O A\* combina o custo já percorrido (`g`) com uma estimativa do custo restante (`h`):

`f(n) = g(n) + h(n)`

Neste projeto, `h(n)` é a distância euclidiana entre o nó atual e o destino. Como as arestas têm pesos compatíveis com distâncias e a heurística não supera a distância em linha reta, ela funciona como estimativa admissível neste mapa didático.

### K-Means
O K-Means particiona os pontos em `k` grupos, aproximando entregas que estão próximas no plano. O algoritmo é usado para apoiar a divisão territorial, não para determinar a ordem exata de visita.

### BFS e DFS
BFS (busca em largura) e DFS (busca em profundidade) são algoritmos de busca em grafos. Eles não foram escolhidos para calcular a rota de menor distância porque, sem considerar os pesos das arestas, não otimizam quilômetros percorridos. A implementação principal utiliza A\*, que considera os pesos.

## 4. Estrutura do projeto

```text
rota_inteligente_projeto/
├── README.md
├── requirements.txt
├── data/
│   ├── entregas.csv
│   └── ruas.csv
├── src/
│   └── main.py
└── outputs/
    ├── rota_otimizada.png
    ├── agrupamento_kmeans.png
    └── resultado.txt
```

## 5. Como executar

Requisitos: Python 3.10 ou superior.

### Instalação

```bash
python -m venv .venv
```

No Windows:

```bash
.venv\Scripts\activate
```

No macOS/Linux:

```bash
source .venv/bin/activate
```

Instale as bibliotecas:

```bash
pip install -r requirements.txt
```

Execute na pasta raiz do projeto:

```bash
python src/main.py
```

O programa imprime os resultados no terminal e atualiza os arquivos da pasta `outputs/`.

## 6. Dados utilizados

Os arquivos CSV contêm:
- `entregas.csv`: identificador e coordenadas fictícias dos locais;
- `ruas.csv`: pares de nós conectados e distância estimada em quilômetros.

O ponto `RESTAURANTE` é a base de saída e retorno. As coordenadas são valores artificiais em um plano cartesiano, não latitude e longitude.

## 7. Avaliação dos resultados

O script compara:
- **rota de referência:** sequência fixa de entregas definida no conjunto didático;
- **rota sugerida:** sequência obtida pela heurística de vizinho mais próximo, usando caminhos A\* entre as paradas.

A métrica principal é a distância total em quilômetros, incluindo o retorno ao restaurante. O resultado numérico exato é gerado ao executar o código e registrado em `outputs/resultado.txt`.

A comparação é ilustrativa: a sequência de referência não representa uma operação real nem uma medição histórica da empresa. Uma redução de distância neste cenário sintético não comprova, por si só, redução equivalente de tempo ou combustível.

## 8. Limitações e melhorias futuras

- Não há dados de trânsito em tempo real, obras, sentido de vias ou restrições de circulação.
- As distâncias são fictícias e o mapa é pequeno.
- O planejamento de paradas usa heurística gulosa, não uma solução exata do problema do caixeiro-viajante.
- O K-Means exige que o número de grupos seja definido previamente e pode variar conforme a inicialização.
- O modelo não considera capacidade dos entregadores, janelas de horário, prioridade dos pedidos ou tempo de preparo.

Como evolução, podem ser adicionados dados geográficos reais, trânsito, janelas de entrega, capacidade dos veículos, comparação com outras heurísticas e otimização global das rotas.

## 9. Conclusão

O protótipo demonstra como grafos, busca heurística e aprendizado não supervisionado podem apoiar decisões logísticas. O A\* encontra caminhos de menor distância no grafo definido, a heurística de vizinho mais próximo organiza as paradas e o K-Means separa entregas em zonas. Mesmo sendo um cenário simplificado, o projeto apresenta uma base reproduzível para estudos de otimização de entregas.

## 10. Referências de estudo

- Hart, P. E.; Nilsson, N. J.; Raphael, B. **A Formal Basis for the Heuristic Determination of Minimum Cost Paths**. IEEE Transactions on Systems Science and Cybernetics, 1968.
- Lloyd, S. **Least squares quantization in PCM**. IEEE Transactions on Information Theory, 1982.
- Documentação oficial do scikit-learn: https://scikit-learn.org/stable/modules/clustering.html#k-means
- Documentação oficial do Python: https://docs.python.org/3/
