import csv
import heapq
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)


def carregar_dados():
    with (DATA / "entregas.csv").open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    nos = {
        r["id"]: {
            "nome": r["nome"],
            "x": float(r["x"]),
            "y": float(r["y"]),
        }
        for r in rows
    }

    grafo = {node_id: {} for node_id in nos}
    with (DATA / "ruas.csv").open(encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f):
            a, b = r["origem"], r["destino"]
            peso = float(r["distancia_km"])
            grafo[a][b] = peso
            grafo[b][a] = peso
    return nos, grafo


def heuristica(a, b, nos):
    """Distância euclidiana entre coordenadas fictícias."""
    dx = nos[a]["x"] - nos[b]["x"]
    dy = nos[a]["y"] - nos[b]["y"]
    return math.hypot(dx, dy)


def a_estrela(inicio, objetivo, grafo, nos):
    """Retorna (caminho, custo_km) usando A*."""
    fila = [(heuristica(inicio, objetivo, nos), 0.0, inicio)]
    anteriores = {}
    melhor_custo = {inicio: 0.0}

    while fila:
        _, custo_atual, atual = heapq.heappop(fila)
        if atual == objetivo:
            caminho = [atual]
            while atual in anteriores:
                atual = anteriores[atual]
                caminho.append(atual)
            caminho.reverse()
            return caminho, custo_atual

        if custo_atual > melhor_custo.get(atual, float("inf")):
            continue

        for vizinho, peso in grafo[atual].items():
            novo_custo = custo_atual + peso
            if novo_custo < melhor_custo.get(vizinho, float("inf")):
                melhor_custo[vizinho] = novo_custo
                anteriores[vizinho] = atual
                prioridade = novo_custo + heuristica(vizinho, objetivo, nos)
                heapq.heappush(fila, (prioridade, novo_custo, vizinho))

    raise ValueError(f"Não existe caminho entre {inicio} e {objetivo}.")


def custo_entre(a, b, grafo, nos):
    return a_estrela(a, b, grafo, nos)[1]


def montar_rota_gulosa(base, entregas, grafo, nos):
    """Escolhe a próxima parada ainda não visitada com menor custo A*."""
    nao_visitadas = set(entregas)
    rota = [base]
    atual = base
    total = 0.0

    while nao_visitadas:
        proxima = min(
            nao_visitadas,
            key=lambda destino: custo_entre(atual, destino, grafo, nos)
        )
        total += custo_entre(atual, proxima, grafo, nos)
        rota.append(proxima)
        nao_visitadas.remove(proxima)
        atual = proxima

    total += custo_entre(atual, base, grafo, nos)
    rota.append(base)
    return rota, total


def medir_rota(rota, grafo, nos):
    total = 0.0
    for a, b in zip(rota, rota[1:]):
        total += custo_entre(a, b, grafo, nos)
    return total


def desenhar_grafo(nos, grafo, rota, arquivo):
    fig, ax = plt.subplots(figsize=(9, 6))
    for a, vizinhos in grafo.items():
        for b, peso in vizinhos.items():
            if a < b:
                ax.plot(
                    [nos[a]["x"], nos[b]["x"]],
                    [nos[a]["y"], nos[b]["y"]],
                    color="#9AA7B2", linewidth=1.5, zorder=1
                )
                mx = (nos[a]["x"] + nos[b]["x"]) / 2
                my = (nos[a]["y"] + nos[b]["y"]) / 2
                ax.text(mx, my, f"{peso:.1f} km", fontsize=7, color="#596875")

    for a, b in zip(rota, rota[1:]):
        ax.annotate(
            "", xy=(nos[b]["x"], nos[b]["y"]),
            xytext=(nos[a]["x"], nos[a]["y"]),
            arrowprops=dict(arrowstyle="->", color="#E07A35", lw=2.5),
            zorder=2
        )

    for node_id, p in nos.items():
        color = "#12304A" if node_id == "RESTAURANTE" else "#168AAD"
        ax.scatter(p["x"], p["y"], s=150, color=color, edgecolor="white", zorder=3)
        ax.text(p["x"] + 0.12, p["y"] + 0.12, node_id, fontsize=9, weight="bold")

    ax.set_title("Grafo didático e sequência de entregas sugerida")
    ax.set_xlabel("Coordenada X fictícia")
    ax.set_ylabel("Coordenada Y fictícia")
    ax.grid(alpha=0.2)
    ax.set_aspect("equal", adjustable="datalim")
    fig.tight_layout()
    fig.savefig(arquivo, dpi=170)
    plt.close(fig)


def desenhar_clusters(nos, ids_entrega, arquivo):
    pontos = [[nos[i]["x"], nos[i]["y"]] for i in ids_entrega]
    modelo = KMeans(n_clusters=2, random_state=42, n_init=10)
    rotulos = modelo.fit_predict(pontos)

    fig, ax = plt.subplots(figsize=(8, 5))
    for grupo in sorted(set(rotulos)):
        xs = [pontos[i][0] for i in range(len(pontos)) if rotulos[i] == grupo]
        ys = [pontos[i][1] for i in range(len(pontos)) if rotulos[i] == grupo]
        ax.scatter(xs, ys, s=120, label=f"Zona {grupo + 1}")
    for i, node_id in enumerate(ids_entrega):
        ax.text(pontos[i][0] + 0.12, pontos[i][1] + 0.12, node_id, fontsize=9)
    centros = modelo.cluster_centers_
    ax.scatter(centros[:, 0], centros[:, 1], marker="X", s=220,
               edgecolor="black", label="Centros")
    ax.set_title("Agrupamento das entregas com K-Means (k=2)")
    ax.set_xlabel("Coordenada X fictícia")
    ax.set_ylabel("Coordenada Y fictícia")
    ax.legend()
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(arquivo, dpi=170)
    plt.close(fig)
    return {node_id: int(rotulos[i]) + 1 for i, node_id in enumerate(ids_entrega)}


def main():
    nos, grafo = carregar_dados()
    base = "RESTAURANTE"
    entregas = [n for n in nos if n != base]

    # Sequência fixa usada apenas como referência comparativa didática.
    rota_referencia = [base, "D1", "D4", "D2", "D6", "D3", "D5", base]
    distancia_referencia = medir_rota(rota_referencia, grafo, nos)

    rota_sugerida, distancia_sugerida = montar_rota_gulosa(
        base, entregas, grafo, nos
    )
    agrupamentos = desenhar_clusters(
        nos, entregas, OUTPUTS / "agrupamento_kmeans.png"
    )
    desenhar_grafo(
        nos, grafo, rota_sugerida, OUTPUTS / "rota_otimizada.png"
    )

    economia = distancia_referencia - distancia_sugerida
    percentual = (economia / distancia_referencia * 100) if distancia_referencia else 0

    linhas = [
        "RESULTADOS - ROTA INTELIGENTE",
        "================================",
        "Dados fictícios para demonstração acadêmica.",
        "",
        "Rota de referência: " + " -> ".join(rota_referencia),
        f"Distância da referência: {distancia_referencia:.2f} km",
        "",
        "Rota sugerida: " + " -> ".join(rota_sugerida),
        f"Distância sugerida: {distancia_sugerida:.2f} km",
        f"Diferença: {economia:.2f} km ({percentual:.1f}%)",
        "",
        "Agrupamento K-Means (k=2):",
    ]
    for node_id, zona in agrupamentos.items():
        linhas.append(f"  {node_id}: Zona {zona}")
    linhas += [
        "",
        "Observação: a rota gulosa é uma heurística e não garante o ótimo global.",
        "As distâncias e coordenadas são sintéticas; não representam trânsito real.",
    ]
    resultado = "\n".join(linhas)
    (OUTPUTS / "resultado.txt").write_text(resultado, encoding="utf-8")
    print(resultado)
    print("\nArquivos gráficos salvos na pasta outputs/.")


if __name__ == "__main__":
    main()
